title: Python 避免踩坑
date: '2019-09-18 10:46:01'
updated: '2019-11-07 16:04:55'
tags: [Python]
permalink: /articles/2019/09/18/1568774761283.html
---
**~~都是我已经踩过的坑~~**
因为国内访问python开源社区很慢，利用pip管理安装包起来比较麻烦，所以更换为国内的开源镜像源仓库，国内有阿里源，清华源，中科大源等等。

#### pip 更换国内源 
以win为例，Linux的话。。你都敢用Linux了，这都不是问题。
在 C:\Users\{你的用户名}\ 下新建一个文件夹 名为 pip
C:\Users\{你的用户名}\pip\ 下新建一个空白文件 名为 pip.ini
加入以下内容 更换为清华源
```
[global]
index-url = https://pypi.tuna.tsinghua.edu.cn/simple
```
保存并退出

linux 环境下 首先定位到根目录
然后检查是否有.pip/文件夹 如果没有就新建一个
```
cd ~ && ls -a 
mkdir .pip/ && cd .pip/ && touch pip.conf && vi pip.conf
# 然后将国内源加入进去 选一个就可以
[global]
https://mirrors.aliyun.com/pypi/simple/
https://pypi.mirrors.ustc.edu.cn/simple/
http://pypi.douban.com/simple/
https://pypi.tuna.tsinghua.edu.cn/simple/
http://pypi.mirrors.ustc.edu.cn/simple/
```

#### Anaconda 科学计算包 
这是一个综合性质仓库合集，基本上新手要用的所有都在里面，包括我们常用的numpy等等，爬虫仓库合集，anaconda环境自带python3，若本地安装了其他版本的python，需要做好版本管理和pip的相应管理。

清华大学 https://mirrors.tuna.tsinghua.edu.cn/anaconda/archive/ 发行版

#### 一键升级pip包/pip
- pip 自更新
```
python -m pip install --upgrade pip
```
- pip 一键升级依赖
把下方的代码复制，并运行
```
# -*- coding: utf-8 -*-
# @ ziheng_wind

from subprocess import call

import pip
from pip._internal.utils.misc import get_installed_distributions

for dist in get_installed_distributions():
    call("pip install --upgrade " + dist.project_name, shell=True)

print("All clear! enjoy now!")
```

#### 虚拟环境的配置使用
在相应的的生产环境中，需要不同的python版本和支持库。我们统一管理一个仓库比较累，所以就需要导入虚拟环境。单独的虚拟环境使用起来方便，而且依赖也很容易补全。~~我不会告诉你是因为为了放在生产环境中方便~~
- 创建虚拟环境
```
python -m venv 虚拟环境名称 
# 此处以python3为例 python自带venv 如果是python2 需要额外的支持库
```
- win下虚拟环境的管理
打开命令行，进入刚刚建立的虚拟环境的目录
```
venv_name\Scripts\activate.bat #进入管理
deactivate.bat # 退出管理
```
- 导出/入相应的pip库
```
venv_name\Scripts\activate.bat #进入管理
pip  freeze > req.txt #导出在生产环境的pip库
pip install -r req.txt # 导入已经配置好的pip库
deactivate.bat  #退出虚拟环境
```

- Linux 的管理是一样的，就是目录不一样
```
venv_name\bin\activate
deactivate
```
