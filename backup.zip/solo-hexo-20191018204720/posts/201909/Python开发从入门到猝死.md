title: Python 开发 从入门到猝死
date: '2019-09-18 10:34:54'
updated: '2019-09-18 13:56:22'
tags: [Python, 猝死]
permalink: /articles/2019/09/18/1568774094616.html
---
##  Flask 前端框架类
- 本地开发时候，处于run.py 即项目启动文件 ，可以写成
```
from app import app
app.run(debug=True)
```
直接调用本地的5000端口进行调试

但处于生产环境时，放置于服务器上，需要写成
```
from app import app

if __name__ == "__main__":

    app.run(debug=True)
```
- flask 和 html 互相传递参数
通过 href 标签传递参数给flask
```
<!-- 后端的路由为 /rents/ -->
<div class="dropdown-content">
 <b><a href="{{ url_for('rents_test',name=0) }}">0 ~ 1K</a></b></div>
```
后端需要接受参数
```
@app.route('/rents/<name>', methods=['GET'])
def rents_test(name):
	pass
```
这样通过get的方式，前端向框架传递参数。

**框架如何给前端传递参数呢**

通过return 函数语句在路由中可以将我们的页面以及想要的参数传递到前端上
```
@app.route('/rents')
def rents():
    return render_template(
        'rents.html',
	name = name #假定name是需要的参数
    )
```
这样 就传递回了组合后的"rents.html" 以及 "name"
前端如何接受呢？
利用Jinja2  直接在网页 中使用
```
{{ name }}
```
就可以将name传递到html中，如果想要传递到js中参与运算呢？
```
var rent_location = "{{name|safe}}";
 /*这里的我设定的name是一个list，因为从flask中传递给js的参数涉及到一个转义的问题 */
```
- 宝塔布置网站相关问题
宝塔添加网站并修改配置文件

```
server {
  listen  80; 
  # listen 443; # 如果配置ssl 就需要添加上这一行
  server_name xxxxxx.com; #你的网址地址
  location / {
    include      uwsgi_params;
    uwsgi_pass   127.0.0.1:8386;  # 指向uwsgi 所应用的内部地址,所有请求将转发给uwsgi 处理 注意宝塔/服务器供应商需要放行这个端口
    uwsgi_param UWSGI_PYHOME /www/wwwroot/xxxxxx.com/demo; # 指向虚拟环境目录
    uwsgi_param UWSGI_CHDIR  /www/wwwroot/xxxxxx.com; # 指向网站根目录
    uwsgi_param UWSGI_SCRIPT run:app; # 指定启动程序，main是main.py前部分,app是程序内用以启动的 application 变量名
  }
}
```
在项目根目录下创建 config.ini

```
[uwsgi]
# uwsgi 启动时所使用的地址与端口，注意服务器提供商和宝塔的端口放行策略
socket = 127.0.0.1:8386
# 指向网站目录
chdir = /www/wwwroot/xxxxx.com
# python 启动程序文件,根据你的实际情况填写
wsgi-file = run.py
# python 程序内用以启动的 application 变量名,根据你的实际情况填写
callable = app
# 处理器数,根据你的实际情况填写
processes = 1
# 线程数
threads = 2
#状态检测地址，注意服务器提供商和宝塔的端口放行策略
stats = 127.0.0.1:9191
```

## HTML  笔记
- 关于样式文件 .css 
所有的样式文件均可以放入一个.css，引入到html中
在.css 中 可以定义一个样式基类 然后在这个样式基类的基础上定义基类下标签的样式
```
.div_test{
	left:50px;
}
.div_test a{
	left:50px;}
```
## Python 开发类
- py3 虚拟环境 相关
```
python3 -m venv {name}

/{name}/bin/activate # linux
/{name}/Scripts/activate # windows

# 运行activate 以后
pip install -r req.txt # 安装测试好的虚拟环境依赖
# 可以理解成环境的快速迁移
pip freeze >req.txt # 输出已经测试好的虚拟环境

```

