title: Python 避免踩坑
date: '2019-09-18 10:46:01'
updated: '2019-09-18 10:46:23'
tags: [Python]
permalink: /articles/2019/09/18/1568774761283.html
---
**~~都是我已经踩过的坑~~**
#### pip 更换国内源 
在 C:\Users\{你的用户名}\ 下新建一个文件夹 名为 pip
C:\Users\{你的用户名}\pip\ 下新建一个空白文件 名为 pip.ini
加入以下内容 更换为清华源
```
[global]
index-url = https://pypi.tuna.tsinghua.edu.cn/simple
```
保存并退出

#### Anaconda 科学计算包 
清华大学 https://mirrors.tuna.tsinghua.edu.cn/anaconda/archive/ 发行版

#### 一键升级pip包/pip
- pip 更新
```
python -m pip install --upgrade pip
```
- pip 一键升级依赖
```
# -*- coding: utf-8 -*-
# @ ziheng_wind

from subprocess import call

import pip
from pip._internal.utils.misc import get_installed_distributions

for dist in get_installed_distributions():
    call("pip install --upgrade " + dist.project_name, shell=True)

print("All clear! enjoy now!")
```


