title: Python 实际运用中的一些坑
date: '2019-10-22 20:37:32'
updated: '2019-11-06 10:57:18'
tags: [Python, 爬虫]
permalink: /articles/2019/10/22/1571747852541.html
---
~~我是不会跟你说我被坑到怀疑猿生的~~
- requests 的ssl验证频繁抛出
因为requests库用的还是urllib ，所以在requests.get()之前加上
```
    urllib3.disable_warnings()
```
即可解决烦人的报错
- SSL验证问题 一般是在设置这个以后才会抛出上面的warning在
requests.get()中加入 
```
verify=False
```
也就是
```
req = requests.get(url, verify=False)
```
- req连接最大 抛出EOF错误
参照如下
```
requests.exceptions.SSLError: HTTPSConnectionPool(host='www.auswaertiges-amt.de', port=443): Max retries exceeded with url: /en/newsroom/news/101210-bm-tag-der-mr/240022 (Caused by SSLError(SSLError("bad handshake: SysCallError(-1, 'Unexpected EOF')")))
```
修改报头，如果有Connection修改为 close
如果没有 则添加上

```
'Connection':'close'
```

~~这里真的是坑我怀疑猿生~~
```
os.getcwd()  # 获取当前目录 返回值是str

os.path.abspath(os.path.join(os.getcwd(), ".."))  # 获取上级目录 返回值是str

#一个字符串需要替换多个内容
str_eg = 'dddddddddddddxxxxxx2222'
str_eg_last = str_eg.replace('d','').replace('2','') #一个字符串可以接多个replace

# 清空文件内容时 需要将文件的游标(这么理解不知道对不对)移动到文件首
f.seek(0)  # 将文件定位到文件首
f.truncate()  # 清空文件

# 定义类时 内部的互相调用
self.调用函数名(self,可加上调用时附加的参数)


```

