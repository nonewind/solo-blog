title: '造一个根据地图选点的flask前端 '
date: '2019-11-07 16:18:40'
updated: '2019-11-11 19:49:14'
tags: [flask, Python]
permalink: /articles/2019/11/07/1573114720735.html
---
**租房子一直是难题，所以我就写了一个租房数据可视化的前端。[点我看看](http://map.ziheng.xyz)，基本上都是东拼西凑出来的东西。本来打算是将这个项目做大的，可是后来不想做了，于是就这样了。我会在后面说清楚如何更改你的地址。**
声明：本项目中的，关于高德API和部分JS代码来自于[实验楼](https://www.shiyanlou.com/) 


github项目地址：https://github.com/nonewind/Flask_58_Rent
Flask超级小白教程：http://www.pythondoc.com/flask-mega-tutorial/index.html 基本就是手把手的教 


## 准备阶段
- 前端框架采用的是flask。为何不用Django？因为我也是刚刚接触前端框架，所以选了一个稍微简单点儿的框架。
- 既然是数据可视化就要使用爬虫，既然有了爬虫就涉及到数据的储存，考虑到租房数据的时效性，采用的是Sqlite。
- 考虑到这个项目未来需要让~~女朋友~~同学使用，所以挂在了服务器上，服务器部署方面采用宝塔，如何部署将会详细说明。

## 代码准备
### 生产环境
- 首先安装宝塔，具体安装命令-百度使用 nginx部署
- 添加一个新的站点 注意域名解析 ps.国内的服务器例如阿里云，如果你购买了他的域名，没有备案的话，会劫持你的80端口限制你的访问
- 进入到刚才添加的站点的目录 在服务器上克隆我的项目源码/或者使用项目发布包 
```
# git clone https://github.com/nonewind/Flask_58_Rent.git
or
# wegt https://github.com/nonewind/Flask_58_Rent/archive/1.0.1.zip && unzip 1.0.1.zip
```
-  在宝塔中设定好项目目录 建立一个py虚拟环境
```
python -m venv venv_name
```
- 在宝塔的网站设置中添加如下内容
```
server {
  listen  80; 
  # listen 443; # 如果配置ssl 就需要添加上这一行
  server_name xxxxxx.com; #你的网址地址
  location / {
    include      uwsgi_params;
    uwsgi_pass   127.0.0.1:8386;  # 指向uwsgi 所应用的内部地址,所有请求将转发给uwsgi 处理 注意宝塔/服务器供应商需要放行这个端口
    uwsgi_param UWSGI_PYHOME /www/wwwroot/xxxxxx.com/demo; # 指向虚拟环境目录
    uwsgi_param UWSGI_CHDIR  /www/wwwroot/xxxxxx.com; # 指向网站根目录
    uwsgi_param UWSGI_SCRIPT run:app; # 指定启动程序，main是main.py前部分,app是程序内用以启动的 application 变量名
  }
}
```
在网站根目录下新建一个config.ini
```
[uwsgi]  
# uwsgi 启动时所使用的地址与端口，注意服务器提供商和宝塔的端口放行策略  
socket = 127.0.0.1:8386  # 指向网站目录  
chdir = /www/wwwroot/xxxxx.com # python 启动程序文件,根据你的实际情况填写  
wsgi-file = run.py # python 程序内用以启动的 application 变量名,根据你的实际情况填写  
callable = app # 处理器数,根据你的实际情况填写  
processes = 1  # 线程数  
threads = 2  #状态检测地址，注意服务器提供商和宝塔的端口放行策略  stats = 127.0.0.1:9191
```
- 安装依赖
```
venv_name/bin/pip install -r req.txt
```
- 启动项目并记录网站日志
```
uwsgi config.ini > /www/wwwroot/website_path/web.log
```
- 访问你的网站 检查结果
### 本地环境
- 默认为win环境 如果为linux环境仅仅需要更改虚拟环境的指向地址
- 克隆我的项目源码/或者使用项目发布包 
```
# git clone https://github.com/nonewind/Flask_58_Rent.git
or
# wegt https://github.com/nonewind/Flask_58_Rent/archive/1.0.1.zip && unzip 1.0.1.zip
```
- 在本地新建一个虚拟环境
```
python -m venv venv_name
```
- 安装相关依赖
```
venv_name/Scripts/pip install -r req.txt
```
- 启动
```
venv_name/Scripts/python run.py
```
- 检查项目
浏览器访问 并检查项目
```
http://127.0.0.1:5000
```

## 修改项目中的地图地址and爬虫地址and数据库文件的生成、修改
### 地图修改
- /app/templates/rents.html
```
center: [120.321892, 36.069283] //自行百度你的城市所在的中心点　并更换
city: "青岛"　//自行更换你所在的城市　有好几处
```
### 数据库生成/修改
- /app/models.py
```
from app import db

class Qingdao_0(db.Model):
    loc = db.Column(db.String(128),index =　True,nullable=True,primary_key = True) #青岛0~500 元 demo
class Qingdao_1(db.Model):
    loc = db.Column(db.String(128),index = True,nullable=True,primary_key = True) #青岛0~500 元 demo
class Qingdao_2(db.Model):
    loc = db.Column(db.String(128),index = True,nullable=True,primary_key = True) #青岛0~500 元 demo

    def __repr__(self)：
        return '<qingdao_0 %r >' % (self.loc)
```
修改其中的　Qingdao_0/1/2 分别对应　０～１ｋ;１ｋ～１．５ｋ；１．５ｋ～２ｋ

然后运行，生成你自己的数据库文件

### 爬虫修改
- sql_write.py
将其中对应上部分的Qingdao_0/1/3修改成你刚生成的数据表
将DATABASE 这个path参数修改成你的绝对目录地址



## 爬虫部分的解释 
- 关于访问网址和头部伪装，全部使用的是手机端进行爬去。因为用电脑端，除非采用多代理的方式去爬取58，不然都是被ban/重定向。考虑到我这就是一小爬虫，没必要整这么复杂就曲线救国了。

- 对于正则和beautifulsoup，我更喜欢正则，但是bs更加的方便，真要比处理速度的话，肯定还是正则更快，我更喜欢短平快。这个爬虫的对抗力小的可怜，就是写来玩玩的。真要用到反反爬虫那一套，那还不知道要写多少代码。肯定不是我这几个循环就能解释的了了。

## flask模板部分的解释
- index.html的背景动态js是直接拿来用的。
- rents.html的高德api使用部分也基本是全抄，我研究了一下，发现没有js的基础，就放弃了。

## 写在最后
- 其实这是我第一次写前端使用flask，很多地方我也不清楚，查了很多的资料，不过确实，查资料的本身也是一种乐趣，全身心的投入一个项目也是一种乐趣，无论在别人严重看起来是否有用，是否用世俗的眼光去看。对于我个人来说，享受这个过程就已经是最大的褒奖。
- 部分填坑在上一篇文章里。
