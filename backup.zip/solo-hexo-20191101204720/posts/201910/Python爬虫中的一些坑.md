title: Python 爬虫中的一些坑
date: '2019-10-22 20:37:32'
updated: '2019-10-22 20:37:56'
tags: [Python, 爬虫]
permalink: /articles/2019/10/22/1571747852541.html
---
~~我是不会跟你说我被坑到怀疑猿生的~~
- requests 的ssl验证频繁抛出
因为requests库用的还是urllib ，所以在requests.get()之前加上
```
    urllib3.disable_warnings()
```
即可解决烦人的报错
- SSL验证问题 一般是在设置这个以后才会抛出上面的warning在
requests.get()中加入 
```
verify=False
```
也就是
```
req = requests.get(url, verify=False)
```
- req连接最大 抛出EOF错误
参照如下
```
requests.exceptions.SSLError: HTTPSConnectionPool(host='www.auswaertiges-amt.de', port=443): Max retries exceeded with url: /en/newsroom/news/101210-bm-tag-der-mr/240022 (Caused by SSLError(SSLError("bad handshake: SysCallError(-1, 'Unexpected EOF')")))
```
修改报头，如果有Connection修改为 close
如果没有 则添加上
```
'Connection':'close'
```
~~这里真的是坑我怀疑猿生~~
